void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");

pinMode(34, OUTPUT);
pinMode(33, OUTPUT);
pinMode(27, OUTPUT);
}

void loop() {
  //lampu merah on
  digitalWrite(34, HIGH);
  delay(15000); // this speeds up the simulation
  //lmapu merah off
  digitalWrite(34, LOW);
  delay(15000);

  //lampu kuning on
  digitalWrite(33, HIGH);
  delay(5000);
  //lampu kuning off
  digitalWrite(33, LOW);
  delay(5000);

  //lampu hijau on
  digitalWrite(27, HIGH);
  delay(15000);
  //lmapu hijau off
  digitalWrite(27, LOW);
  delay(15000);
}
